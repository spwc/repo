import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://www.dropbox.com/s/1i98cw14bcnr7i1/builds.json?dl=1'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://www.dropbox.com/s/wzwh1waae3gxfmp/notify.txt?dl=1'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
